#pragma once
#ifndef _SCENE_1_H_
#define _SCENE_1_H_

#include"cocos2d.h"
#include"cocos-ext.h"
#include"Scene_2.h"
//#include"FileManager.h"

using namespace std;
USING_NS_CC;

const int minSwipdistance = 100;
const int minSwiptime = 1000;    //����  
const int maxClickedDis = 20;


class Scene_1 :public CCLayer
{
public:
	Scene_1() {}
	~Scene_1(){}
	static CCScene* createScene();
	virtual bool init();

	//��Ļ�����¼�
	bool onTouchBegan(Touch* touch, Event* event);
	void onTouchMoved(Touch* touch, Event* event);     //�˴��ɲ�ʵ��
	void onTouchEnded(Touch* touch, Event* event);
	void selectSpriteForTouch(Point touchLocation);

	void updateSingleDelay(float);
	void updateDoubleDelay(float);
	long long getCurrentTime();
	CREATE_FUNC(Scene_1);

	void showAttribute(cocos2d::Ref* pSender);
	void openComputer(cocos2d::Ref*pSender);

	void closeAttribute(cocos2d::Ref* pSender);
	
private:
	CCSprite* computer;
	CCSprite* FileFrame;
	Sprite *attribute;    //�����д��Ľ�
	Size size;
	bool isTouch;
	
	int touchCounts;

	long long m_startTime;
	//E_SWIP_DIR GetSwipDir(cocos2d::CCPoint start, cocos2d::CCPoint end, long long timeDis);

public:
	virtual void onSingleCLick();        //����  
	virtual void onDoubleClick();        //˫��  
};


#endif