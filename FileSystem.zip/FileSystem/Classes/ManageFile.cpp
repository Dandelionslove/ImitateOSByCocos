#include "ManageFile.h"

fileDirec::fileDirec()
{
	dhead = new FCB(0, "\0", "package", "\0", NULL);      //�ļ�Ŀ¼����ͷ������Ϣ��ʼ��
	currentParent = dhead;
	currentFileNode = NULL;
	maxlen = maxByte;
	dcurrentlen = 0;
}


bool fileDirec::_dsearch(FCB * parent, string name)
{
	for (int i = 0; i < maxNum; i++)
	{
		if (parent->fchilds[i] != NULL)
		{
			if (parent->fchilds[i]->fname == name)
			{
				return true;
			}
		}
	}
	return false;
}

void fileDirec::dinsert(string name,string type)
{
	int i = 0;
	for (; i < maxNum; i++)
	{
		if (currentParent->fchilds[i] == NULL)break;
	}
	string adress;
	if (currentParent == dhead)
	{
		adress = "C";
	}
	else { adress = currentParent->fadress + ">" + currentParent->fname; }
	currentParent->fchilds[i] = new FCB(i, name, type, adress, currentParent);      //�ļ��ź�����ֵһ��
	//FCB* temp = currentParent->fchilds[i];
	currentFileNode = NULL;
	//������ʾ��ҳ������������������
}

bool fileDirec::ddelete(FCB* curnode)  //false error:notfound
{
	if (curnode == NULL)
	{
		MessageBox("Sorry!The node to delete is NULL","");
		return false;
	}
	////////////�����ļ��е��ֽڴ�С
	FCB*temp = curnode->fparent;
	while (temp != NULL)
	{
		temp->fcurrentlen = temp->fcurrentlen - curnode->fcurrentlen;
		temp = temp->fparent;
	}
	dcurrentlen = dhead->fcurrentlen;
	////////////���ĵ�ǰ������Ϣ
	curnode->fparent->fchilds[curnode->fnum] = NULL;
	_delete(curnode);
	return true;
}

void fileDirec::search(FCB *result[], FCB*parent, string name,int m)  //nΪresult����Ĵ�С����ϵͳ����10�����ˣ�С���ļ�ϵͳ;mΪ��ǰ��ָ����±�������ҵ����ļ�����
{                                                                            //һҳ�ܹ�չʾ���������Ҳ��maxNum���ļ�����n����ʱȡmaxNum
	if (parent == NULL)return;
	if (m > maxNum)return;    //�޶��ҵ����ļ���������ҳ��ռ�չʾ����
	for (int i = 0; i < maxNum; i++)
	{
		if (parent->fchilds[i] != NULL&&parent->fchilds[i]->fname == name)
		{
			result[m] = new FCB(i, name, parent->fchilds[i]->ftype, parent->fchilds[i]->fadress, parent);
			/////��Ϊ�ļ���doc��package�����Ի���������ͬ��ʱ��
			m++;
			if (m > maxNum)return;
		}
	}
	for (int i = 0; i < maxNum; i++)
	{
		search(result, parent->fchilds[i], name, m );
	}
}


void fileDirec::_delete(FCB * h)
{
	if (h == NULL)return;
	else
	{
		for (int i = 0; i < maxNum; i++)
		{
			_delete(h->fchilds[i]);
		}
		delete h;
	}
}

bool fileDirec::is_full()
{
	for (int i = 0; i < maxNum; i++)
	{
		if (currentParent->fchilds[i] == NULL)return false;
	}
	
	{
		//error = "full";
		return true;
	}
}

bool fileDirec::is_repeat(string insertname,string type)
{
	for (int i = 0; i < maxNum; i++)
	{
		if (currentParent->fchilds[i] != NULL)
		{
			if (currentParent->fchilds[i]->fname == insertname&&currentParent->fchilds[i]->ftype==type)return true;
		}
	}
	//error = "repeatname";
	return false;
}

bool fileDirec::is_ware_will_full(string oldc, string newc)
{
	int len = dcurrentlen - oldc.size();
	int newlen = len + newc.size();
	if(newlen>maxlen)
	return true;
	else return false;
}

void fileDirec::resetcontent(string newc)
{
	int oldlen = currentFileNode->fcurrentlen;
	currentFileNode->fcontent = newc;
	currentFileNode->fcurrentlen = newc.size();
	FCB* p = currentParent;
	while (p != NULL)
	{
		p->fcurrentlen = p->fcurrentlen - oldlen + newc.size();   //���̼�Ϊdhead
		p = p->fparent;
	}
	dcurrentlen = dhead->fcurrentlen;
}





ManageFile::ManageFile() :/*openhead(NULL),*//* currentFileNode(NULL),*/ current_dir_adress("C>")/*,currentParent(direc.gethead())*/ //һ���C�̵�ͼ���ַ�������
{
}


void ManageFile::createfile(string name, string type)
{
	direc.dinsert( name, type);
}

void ManageFile::set_currentFileNode(FCB * newcur)
{
	direc.currentFileNode = newcur;
}

void ManageFile::set_currentParent(FCB * newcur)
{
	direc.currentParent = newcur;
}

//bool ManageFile::deletefile()
//{
//	return direc.ddelete(currentFileNode->fparent, currentFileNode->fname);
//}

//bool ManageFile::renamefile(string newname)
//{
//	if (currentFileNode == NULL)return false;
//	currentFileNode->fname = newname;
//	currentFileNode->update_fileShow();
//	return true;
//}

//void ManageFile::search(FCB * result[], string name,  int m)
//{
//	direc.search(result, direc.gethead(), name, m);
//}



//bool ManageFile::read()
//{
//	if (currentFileNode != NULL)
//	{
//		currentParent = currentFileNode;
//		currentFileNode = NULL;
//		return true;
//	}
//	return false;
//}

//bool ManageFile::write()
//{
//	if (currentFileNode->fstate == "rw")
//	{
//		currentParent = currentFileNode;
//		currentFileNode = NULL;
//		return true;
//	}
//	return false;
//}

//bool ManageFile::open()
//{
//	return false;
//}

//bool ManageFile::close()
//{
//	currentParent = currentFileNode->fparent;
//	currentFileNode = NULL;
//	return true;
//}

void ManageFile::search(FCB *result[], string name, int m)
{
	direc.search(result, get_direc_head(), name, m);
}

int ManageFile::getcurrentlen()
{
	return direc.getcurrentlen();
}

attribute ManageFile::get_attribute() //��ǰ��㲻Ϊ�յ�����µ���
{
	attribute requisite;
	requisite.adress = direc.currentFileNode->fadress;
	requisite.currentlen = direc.currentFileNode->fcurrentlen;
	requisite.name = direc.currentFileNode->fname;
	requisite.state = direc.currentFileNode->fstate;
	requisite.type = direc.currentFileNode->ftype;
	return requisite;
}



//bool ManageFile::is_can_create(string &error)
//{
//	if(direc.)
//}

//void FCB::update_fileShow()
//{
//	auto name_inf = CCLabelTTF::create(fname, "UWJACK8", 20);      //����
//	char num[5];
//	auto size_inf = CCLabelTTF::create(itoa(fcurrentlen, num, 10), "UWJACK8", 20);
//	_fileButt->addChild(name_inf);
//	_fileButt->addChild(size_inf);
//	name_inf->setPosition(20, 20);    //����
//	size_inf->setPosition(40, 20);     //����
//	name_inf->setColor(ccc3(0, 0, 0));
//	size_inf->setColor(ccc3(0, 0, 0));
//}

//void FCB::fileShowFunc(Ref * p)
//{
//	is_selected = true;
//}


