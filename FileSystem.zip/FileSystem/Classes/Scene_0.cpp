#include "Scene_0.h"

Scene_0::Scene_0()
{
	
}

CCScene * Scene_0::createScene()
{
	auto scene = CCScene::create();
	Scene_0 *Layer = Scene_0::create();
	scene->addChild(Layer);
	return scene;
}

bool Scene_0::init()
{
	if (!Layer::init())
	{
		return false;
	}
	size = Director::getInstance()->getVisibleSize();

	//��������
	auto background = Sprite::create("background_2.png");
	this->addChild(background);
	background->setPosition(size.width / 2, size.height / 2);
	//
	auto words = CCLabelTTF::create("This is a simple file system", "UWJACK8", 30);
	words->setFontFillColor(ccc3(60, 60, 60), true);
	auto show_1 = CCScaleBy::create(2.0, 2.0f);
	words->runAction(show_1);
	this->addChild(words);
	words->setPosition(size.width / 2, size.height / 2);
	//
	auto begin = CallbackTimeCounter::create();
	this->addChild(begin);
	begin->start(1.5f, [=] 
	{
		CCDirector::sharedDirector()->replaceScene(CCTransitionPageTurn::create(2.0f, Scene_2::createScene(), true));
	});
	return true;
}
