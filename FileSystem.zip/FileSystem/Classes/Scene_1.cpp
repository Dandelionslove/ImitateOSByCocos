#include "Scene_1.h"
#include"CallbackTimeCounter.h"

CCScene * Scene_1::createScene()
{
	auto scene = CCScene::create();
	Scene_1 *Layer = Scene_1::create();
	scene->addChild(Layer);
	return scene;
}

bool Scene_1::init()
{
	if (!Layer::init())
	{
		return false;
	}
	size = Director::getInstance()->getVisibleSize();
	auto background = CCSprite::create("backGround_1.png");
	this->addChild(background);
	background->setPosition(size.width / 2, size.height / 2);
	computer = CCSprite::create("computer.png");
	this->addChild(computer);
	computer->setScale(0.07);
	computer->setPosition(100, size.height - 150);
	auto tag = CCLabelTTF::create("My Computer", "UWJACK8",300);
	computer->addChild(tag);
	auto size_1 = computer->getContentSize();
	tag->setPosition(size_1.width / 2, -10);

	//��˫��ʵ��
	isTouch = false;
	touchCounts = 0;
	setTouchEnabled(true);
	
	//�������¼���ʵ��
	//background->se
	auto listener = EventListenerTouchOneByOne::create();
	listener->setSwallowTouches(true);
	listener->onTouchBegan = CC_CALLBACK_2(Scene_1::onTouchBegan, this);
	listener->onTouchMoved = CC_CALLBACK_2(Scene_1::onTouchMoved, this);
	listener->onTouchEnded = CC_CALLBACK_2(Scene_1::onTouchEnded, this);
	_eventDispatcher->addEventListenerWithSceneGraphPriority(listener, this);

	return true;
}

bool Scene_1::onTouchBegan(Touch * touch, Event * event)
{
	Point touchLocation = this->convertTouchToNodeSpace(touch);
	this->selectSpriteForTouch(touchLocation);
	CCLOG("ccTouchBegan");
	isTouch = true;
	m_startTime = getCurrentTime();
	//�����¼�  
	return true;
}

void Scene_1::onTouchMoved(Touch * touch, Event * event)
{
}


void Scene_1::onTouchEnded(Touch * touch, Event * event)
{
	CCLOG("ccTouchEnded");
	isTouch = false;
	long long endTime = getCurrentTime();
	long long timeDis = endTime - m_startTime;
	
	if (touchCounts == 2) {
		touchCounts = 0;
		onDoubleClick();
	}
	else if (touchCounts == 1) {
		this->scheduleOnce(schedule_selector(Scene_1::updateDoubleDelay), 0.1);
		touchCounts++;
	}
	else if (touchCounts == 0) {
		this->scheduleOnce(schedule_selector(Scene_1::updateSingleDelay), 0.2);
		touchCounts++;
	}
}

void Scene_1::selectSpriteForTouch(Point touchLocation)
{
	CCSprite* p = computer;
	if (p->getBoundingBox().containsPoint(touchLocation))
	{
		//�˴��ɲ���
	}
}

long long Scene_1::getCurrentTime()
{
	struct timeval tm;
	gettimeofday(&tm, NULL);
	return (long long)(tm.tv_sec * 1000 + tm.tv_usec / 1000);
}

void Scene_1::showAttribute(cocos2d::Ref * pSender)
{
	attribute = CCSprite::create("attr_content.png");
	this->addChild(attribute);
	attribute->setPosition(size.width / 2, size.height / 2);
	setTouchEnabled(false);
	auto close_attr = CCMenuItemImage::create("close_attr.png", "close_attr.png", CC_CALLBACK_1(Scene_1::closeAttribute, this));
	auto _close_attr = Menu::create(close_attr, NULL);
	attribute->addChild(_close_attr);
	_close_attr->setPosition(100, 200);
}

void Scene_1::openComputer(cocos2d::Ref * pSender)
{
	CCDirector::sharedDirector()->pushScene(Scene_2::createScene());
}

void Scene_1::closeAttribute(cocos2d::Ref * pSender)
{
	setTouchEnabled(true);
	this->removeChild(attribute);
}

void Scene_1::updateDoubleDelay(float)
{
	if (touchCounts == 2)
	{
		onDoubleClick();
		touchCounts = 0;
	}
}

void Scene_1::updateSingleDelay(float)
{
	if (touchCounts == 1)
	{
		onSingleCLick();
		touchCounts = 0;
	}
}


void Scene_1::onSingleCLick()
{
	//CCLOG("onSingleCLick");
	//��ʾ��Ϣ--button
	auto menu_1 = MenuItemImage::create("attribute.png", "attribute.png", CC_CALLBACK_1(Scene_1::showAttribute, this));
	auto menu_2 = MenuItemImage::create("open.png", "open.png", CC_CALLBACK_1(Scene_1::openComputer, this));
	auto menu = Menu::create(menu_1, menu_2, NULL);
	this->addChild(menu);
	//Vec2 c_pos = computer->getPosition();
	menu->setPosition(0.001,200);
	menu->alignItemsVertically();
	menu->setScale(0.2);
	auto remove_menu = CallbackTimeCounter::create();
	this->addChild(remove_menu);
	remove_menu->start(2.0f, [=]()
	{
		this->removeChild(menu);
	}
	);
}

void Scene_1::onDoubleClick()
{
	//CCLOG("onDoubleClick");
	/*FileFrame = Sprite::create("FileFrame.png");
	this->addChild(FileFrame);
	FileFrame->setPosition(size.width / 2, size.height / 2);*/

	CCDirector::sharedDirector()->pushScene(Scene_2::createScene());
}


