#pragma once
#ifndef _Scene_0_H_
#define _Scene_0_H_

#include"cocos2d.h"
#include"scene_1.h"
#include"CallbackTimeCounter.h"
using namespace cocos2d;
USING_NS_CC;

class Scene_0 :public CCLayer
{
public:
	Scene_0();
	~Scene_0(){}
	static CCScene* createScene();
	virtual bool init();

	CREATE_FUNC(Scene_0);
private:
	Size size;
	CCSprite* backgroud;
};
#endif
