#include "Scene_2.h"

Scene_2::Scene_2()
{
}

CCScene * Scene_2::createScene()
{
	auto scene = CCScene::create();
	Scene_2 *Layer = Scene_2::create();
	scene->addChild(Layer);
	return scene;
}

bool Scene_2::init()
{
	if (!Layer::init())
	{
		return false;
	}
	size = Director::getInstance()->getVisibleSize();
	level = 31;
	//ϵͳ����
	FileFrame = Sprite::create("FileFrame.png");
	this->addChild(FileFrame);
	FileFrame->setPosition(size.width / 2, size.height / 2);
	///////��Ч������־��ʼ��
	is_valid = true;
	//ʹ��ָ�ϰ�ť
	_readme = MenuItemImage::create("readmeButt_1.png", "readmeButt_2.png", CC_CALLBACK_1(Scene_2::ReadMe, this));
	readme = Menu::create(_readme, NULL);
	this->addChild(readme,30);
	readme->setPosition(70, 400);
	//�ļ�ϵͳ�رհ�ť
	_closeFrame = MenuItemImage::create("closeFrame.png", "closeFrame_.png", CC_CALLBACK_1(Scene_2::closeFrameFunc, this));
	closeFrame = Menu::create(_closeFrame, NULL);
	closeFrame->setPosition(size.width-27, size.height-20);
	//_closeFrame->setScale(0.6);
	this->addChild(closeFrame);
	      /////////////������ť����
	auto search = Sprite::create("search.png");
	search->setScale(0.15);
	search->setPosition(size.width - 200, size.height - 25);
	searchBox = EditBox::create(Size(search->getContentSize().width*0.15, search->getContentSize().height*0.15), Scale9Sprite::create("search.png"));
	//searchBox->setScale(0.15);
	searchBox->setPosition(search->getPosition());
	searchBox->setMaxLength(20);        ////
	searchBox->setText("Search file......");
	searchBox->setFontSize(20);
	searchBox->setPlaceHolder("Please input the file's name you want to search:");
	searchBox->setFontColor(Color3B(0,0,0));
	searchBox->setFontSize(20);
	this->addChild(searchBox);
	auto okButton = MenuItemImage::create("searchButton.png", "searchButton.png");       //ͼƬ����
	okButton->setCallback([=](Ref*obj) {                                      //�û���������Ҫ�������ļ���Ȼ����ļ�����ֵ����search_file_name
		char*_search_file_name =(char*) searchBox->getText();
		string search_file_name = Value(_search_file_name).asString();
		SearchOk(search_file_name);
	});
	okButton->setScale(0.15);
	auto okMenu = Menu::create(okButton, NULL);
	okMenu->setPosition(size.width/2+359, size.height-25);
	this->addChild(okMenu);

	//��ʼҳ��Ĵ��̰�ť
	wareC1 = MenuItemImage::create("C.png", "C.png", CC_CALLBACK_1(Scene_2::towareC, this));
	wareC1 -> setScale(0.6);
	//wareD2->setScale(0.2);
	wareMenu1 = Menu::create(wareC1,/* wareD2,*/ NULL);
	wareMenu1->setPosition(70,200 );
	this->addChild(wareMenu1);
	//C�̿��ÿռ�ʣ���С��ʼ��ʾ����file����������
	char clen[10];
	Csize = CCLabelTTF::create(itoa(filemanager.getcurrentlen(), clen, 10), "UWJACK8", 10);
	this->addChild(Csize);
	Csize->setPosition(70, 185);        
	Csize->setColor(ccc3(236, 25, 25));
	//C���ܿռ��С��ʾ
	char _clen[10];
	auto totallen = CCLabelTTF::create(itoa(maxByte, _clen, 10), "UWJACK8", 10);
	this->addChild(totallen);
	totallen->setPosition(70, 165);
	totallen->setColor(ccc3(37,199,189));
	//·����ʼ��ʾ
	currentadress = CCLabelTTF::create("C", "UWJACK8", 25);
	this->addChild(currentadress);
	currentadress->setPosition(180, size.height - 30);    
	currentadress->setColor(ccc3(33,33,222));
	///////////////////·��ǰ�����˰�ť      
	left = false;
	right = false;
	leftarrow0 = MenuItemImage::create("_backButt.png", "_backButt.png");
	rightarrow0 = MenuItemImage::create("_nextButt.png", "_nextButt.png");
	leftarrow0->setCallback([=](Ref*obj) 
	{
		MessageBox("Sorry,this is the first page!", "");
	});
	leftarrow0->setCallback([=](Ref*obj)
	{
		MessageBox("Please select a file to open!", "");
	});
	arrowMenu = Menu::create(leftarrow0, rightarrow0, NULL);
	this->addChild(arrowMenu);
	leftarrow0->setScale(0.13);
	rightarrow0->setScale(0.13);
	arrowMenu->alignItemsHorizontallyWithPadding(5);
	arrowMenu->setPosition(50, size.height - 30);

	//����ʱ�ҵ����ļ�չʾҳ��ʼ�����㼶Ϊ-1
	//showFound = Sprite::create("BlankArea.png");
	//this->addChild(showFound);
	//showFound->setPosition(size.width / 2+10, size.height / 2-10);    //���ģ�����PS������Ϣ����     //standard
	//showFound->setGlobalZOrder(-1);

	//////�ļ�չʾ����
	is_search_page = false;         //�Ƿ����������Ľ��չʾ
	currentShowpage = Sprite::create("blankArea.png");        
	this->addChild(currentShowpage);        
	currentShowpage->setPosition(size.width / 2+68, size.height / 2-40);   
	///////////�½��ļ�
	buildnewP = MenuItemImage::create("BuildNewFileP_1.png", "BuildNewFileP_2.png",CC_CALLBACK_1(Scene_2::_buildP,this));
	buildnewD = MenuItemImage::create("BuildNewFileD_2.png", "BuildNewFileD_2.png",CC_CALLBACK_1(Scene_2::_buildD,this));
	//////////���ļ�
	open = MenuItemImage::create("open_1.png", "open_2.png");
	open->setCallback([=](Ref*obj) 
	{
		_open(filemanager.get_currentNode());
	});
	//////////ɾ���ļ�
	deletefile = MenuItemImage::create("delete_1.png", "delete_2.png", CC_CALLBACK_1(Scene_2::_delete, this));
	///////////չʾ����
	show_attribute = MenuItemImage::create("attribute_1.png","attribute_2.png",CC_CALLBACK_1(Scene_2::_show_attribute,this));
	///////�ļ�������
	rename = MenuItemImage::create("rename_1.png", "rename_2.png", CC_CALLBACK_1(Scene_2::_rename, this));
	operationMenu = Menu::create(buildnewP, buildnewD,open,deletefile,show_attribute,rename, NULL);
	operationMenu->alignItemsVerticallyWithPadding(3);
	operationMenu->setPosition(870, 400);            //����

	this->addChild(operationMenu,30);    //�㼶�ߣ����ⲻ��Ҫ�ĸ���
	return true;
}

void Scene_2::closeFrameFunc(Ref * p)
{
	//Director::sharedDirector()->pushScene(Scene_1::createScene());
	MessageBox("You pressed the close button.The application is over!", "Alert");
	CCDirector::sharedDirector()->end();

	exit(0);
}

void Scene_2::OkButton()
{
	this->removeChild(editbox);
}

void Scene_2::ReadMe(Ref * p)
{
	if (is_valid == false)
	{
		MessageBox("Please finish your other operations first!", "");
		return;
	}
	is_valid = false;
	if (right == true)
	{
		right = false;
		updateArrowState();
	}
	Sprite* ins = Sprite::create("ins.png");
	this->addChild(ins,31);
	ins->setPosition(size.width / 2, size.height / 2);
	auto _close_ins = MenuItemImage::create("close_ins_1.png", "close_ins_2.png");
	auto close_ins = Menu::create(_close_ins, NULL);
	ins->addChild(close_ins);
	close_ins->setPosition(900, 600);
	_close_ins->setCallback([&, ins](Ref*obj) 
	{
		is_valid = true;
		this->removeChild(ins);
	});
}

void Scene_2::SearchOk(string _search_file_name)
{
	if (is_valid == false)
	{
		MessageBox("Please finish your other operations fisrt!", "");
		searchBox->setText("Search file......");
		return;
	}
	is_valid = false;
	FCB*foundfile[maxNum] = { NULL };
	//FCB *foundfife = new FCB(0, "", "package", "", NULL);
	filemanager.search(foundfile, _search_file_name, 0);
	////////�������Ҽ�ͷ////////��ǰ����㲻��
	right = false;
	is_search_page = true;
	updateArrowState();
	//////////չʾ�ҵ��Ľ��
	////////����չʾ��ǰҳ����
	currentShowpage->removeAllChildren();
	Size _size = currentShowpage->getContentSize();
	if (foundfile[0] == NULL)
	{
		MessageBox("Sorry!No such file is found!", "");
		searchBox->setText("Search file......");
	}
	else
	{
	for (int i = 0; i < maxNum; i++)
	{
		FCB* temp = foundfile[i];
		if (temp != NULL)
		{
			MenuItemImage* _file_type;
			if (temp->ftype == "package")
			{
				_file_type = MenuItemImage::create("package.png", "package.png");
			}
			else
			{
				_file_type = MenuItemImage::create("doc.png", "doc.png");
			}
			auto file_type = Menu::create(_file_type, NULL);
			_file_type->setCallback([=](Ref*obj)
			{
				filemanager.set_currentFileNode(temp);    //������ļ����ĵ�ǰ���ֵ
				right = true;    //������ļ�����ǰ��
				updateArrowState();
			});
			currentShowpage->addChild(file_type);
			file_type->setPosition(90, _size.height - _size.height / maxNum*(i + 1));     //����
			_file_type->setScale(0.04);
			auto name_inf = CCLabelTTF::create(temp->fname, "UWJACK8", 20);      //����
			char num[5];
			auto size_inf = CCLabelTTF::create(itoa(temp->fcurrentlen, num, 10), "UWJACK8", 20);
			currentShowpage->addChild(name_inf);
			currentShowpage->addChild(size_inf);
			name_inf->setPosition(200, _size.height - _size.height / maxNum*(i + 1));    //����
			size_inf->setPosition(300, _size.height - _size.height / maxNum*(i + 1));     //����
			name_inf->setColor(ccc3(0, 0, 0));
			size_inf->setColor(ccc3(0, 0, 0));
			auto addr_inf = CCLabelTTF::create(temp->fadress, "UWJACK8", 20);
			currentShowpage->addChild(addr_inf);
			//addr_inf->setAnchorPoint(Vec2(0, 0));
			addr_inf->setPosition(440, _size.height - _size.height / maxNum*(i + 1));
			addr_inf->setColor(ccc3(0, 0, 0));
			//MessageBox("Not NULL!", "");
		}
	}
}
	////////������ʾ��ַ
	this->removeChild(currentadress);
	string newAddr = "The file found:";
	currentadress = CCLabelTTF::create(newAddr.c_str(), "UWJACK8", 25);
	this->addChild(currentadress);
	currentadress->setAnchorPoint(Vec2(0, 0));
	currentadress->setPosition(180, size.height - 30);
	currentadress->setColor(ccc3(33, 33, 222));
	is_valid = true;
}

void Scene_2::towareC(Ref * p)
{
	if (is_valid == false)
	{
		MessageBox("Please finish your other operations first!", "");
		return;
	}
	///����ǰ���ǵ�һҳ��ֱ�ӷ���
	if (filemanager.isfirstPage())
	{
		right = false;  //rightArrowʧЧ
		updateArrowState();   //���¼�ͷ״̬
		return;
	}
	///////���ǵ�һҳ����չʾ��ǰ����
	//////���¼�ͷ��Ϣ
	///left = false;
	/////���õ�ǰ�����
	filemanager.set_currentParent(filemanager.get_direc_head());
	right = false;
	updateArrowState();
	///////���µ�ǰչʾҳ��Ϣ
	reshow_thispackage(filemanager.get_direc_head());
	//////���µ�ַչʾ��Ϣ
	this->removeChild(currentadress);
	string newAddr = "C";
	currentadress = CCLabelTTF::create(newAddr.c_str(), "UWJACK8", 25);
	this->addChild(currentadress);
	currentadress->setAnchorPoint(Vec2(0, 0));
	currentadress->setPosition(180, size.height - 30);
	currentadress->setColor(ccc3(33, 33, 222));
}

void Scene_2::modifyCurrentlen()
{
	this->removeChild(Csize);
	char clen[10];
	Csize = CCLabelTTF::create(itoa(filemanager.getcurrentlen(), clen, 10), "UWJACK8", 10);
	this->addChild(Csize);
	Csize->setPosition(70, 185);
	Csize->setColor(ccc3(236, 25, 25));
}

void Scene_2::_buildP(Ref * p)
{
	if (is_valid == false)
	{
		MessageBox("Please finish your other operations first!", "");
		return;
	}
	is_valid = false;
	if (right == true)
	{
		right = false;
		updateArrowState();
	}
	if (is_search_page == true)
	{
		MessageBox("Sorry!You can't create a new file here!", ""); 
		is_valid = true;
		return;
	}
	if (filemanager.is_page_full())    //�����
	{
		show_fullmessage(); 
		is_valid = true;
		return;
	}
	//�������
	auto nameBox = Sprite::create("namebox1.png");
	this->addChild(nameBox);
	nameBox->setPosition(size.width / 2, size.height / 2);
	auto setnameBox = EditBox::create(Size(nameBox->getContentSize().width, nameBox->getContentSize().height), Scale9Sprite::create("namebox1.png"));
	//setnameBox->setScale(0.15);
	setnameBox->setPosition(nameBox->getPosition());
	setnameBox->setMaxLength(20);
	setnameBox->setPlaceHolder("Please input the file's name:");
	setnameBox->setText("Untitled");
	setnameBox->setFontColor(Color3B(100,100,100));
	setnameBox->setFontSize(20);
	this->addChild(setnameBox);

	auto nameokButt= MenuItemImage::create("nameok_1.png", "nameok_2.png");       //ͼƬ����
	auto okMenu = Menu::create(nameokButt, NULL);
	okMenu->setPosition(100,18);
	nameokButt->setScale(0.7);
	setnameBox->addChild(okMenu);
	nameokButt->setCallback([=](Ref*obj) {                                      
		char *_newname= (char *)setnameBox->getText();
		//MessageBox(_newname, "");             //������
		string newname = Value(_newname).asString();
		bool is_name_repeated = filemanager.is_name_repeated(/*Value(_newname).asString()*/newname,"package");
		if (is_name_repeated)
		{
		MessageBox("name repeated!", "Alert");
		this->removeChild(nameBox, true);
		this->removeChild(setnameBox, true);
		}
		else
		{
			MessageBox("File created successful!", "");
			this->removeChild(nameBox, true);
			this->removeChild(setnameBox, true);

			filemanager.createfile(newname, "package");
			reshow_thispackage(filemanager.get_currentParent());
		}
		is_valid = true;
	});
	//nameokButt->setScale(0.5);
	
}

void Scene_2::_buildD(Ref * p)
{
	if (is_valid == false)
	{
		MessageBox("Please finish your other operations first!", "");
		return;
	}
	is_valid = false;
	if (right == true)
	{
		right = false;
		updateArrowState();
	}
	if (is_search_page == true)
	{
		MessageBox("Sorry!You can't create a new file here!", ""); 
		is_valid = true;
		return;
	}
	if (filemanager.is_page_full())    //�����
	{
		show_fullmessage();
		is_valid = true;
		return;
	}
	//�������
	auto nameBox = Sprite::create("namebox1.png");
	this->addChild(nameBox);
	nameBox->setPosition(size.width / 2, size.height / 2);
	auto setnameBox = EditBox::create(Size(nameBox->getContentSize().width, nameBox->getContentSize().height), Scale9Sprite::create("namebox1.png"));
	//setnameBox->setScale(0.15);
	setnameBox->setPosition(nameBox->getPosition());
	setnameBox->setMaxLength(20);
	setnameBox->setPlaceHolder("Please input the file's title:");
	setnameBox->setText("Untitled");
	setnameBox->setFontColor(Color3B(100,100,100));
	setnameBox->setFontSize(20);
	this->addChild(setnameBox);

	auto nameokButt = MenuItemImage::create("nameok_1.png", "nameok_2.png");       //ͼƬ����
	auto okMenu = Menu::create(nameokButt, NULL);
	okMenu->setPosition(100, 18);
	nameokButt->setScale(0.7);
	setnameBox->addChild(okMenu);
	nameokButt->setCallback([=](Ref*obj) {
		char *_newname = (char *)setnameBox->getText();
		//MessageBox(_newname, "");             //������
		string newname = Value(_newname).asString();
		bool is_name_repeated = filemanager.is_name_repeated(/*Value(_newname).asString()*/newname, "doc");
		if (is_name_repeated)
		{
			MessageBox("name repeated!", "Alert");
			this->removeChild(nameBox, true);
			this->removeChild(setnameBox, true);
		}
		else
		{
			MessageBox("File created successful!", "");
			this->removeChild(nameBox, true);
			this->removeChild(setnameBox, true);

			filemanager.createfile(newname, "doc");
			reshow_thispackage(filemanager.get_currentParent());
		}
		is_valid = true;
	});
	//nameokButt->setScale(0.5);
}

void Scene_2::show_repeatemessage()
{
	MessageBox("Sorry!The name is repeated!", "");
}

void Scene_2::show_fullmessage()
{
	MessageBox("Sorry!The current table is full!\nPlease choose another table to create a new file!", "");
}

void Scene_2::reshow_thispackage(FCB * parent)           //չʾ���ǵ�ǰpackageҳ�����ݣ�ֻ�����package
{                                                       //���ݰ����ĵ���ͼ������֣����ڴ�С
	currentShowpage->removeAllChildren();
	//this->removeChild(currentShowpage);

	Size _size = currentShowpage->getContentSize();
	for (int i = 0; i < maxNum; i++)
	{
		FCB* temp = parent->fchilds[i];
		if (temp != NULL)
		{
			MenuItemImage* _file_type;
			if (temp->ftype == "package")
			{
				_file_type = MenuItemImage::create("package.png", "package.png");
			}
			else
			{
				_file_type = MenuItemImage::create("doc.png", "doc.png");
			}
			auto file_type = Menu::create(_file_type, NULL);
			_file_type->setCallback([=](Ref*obj) 
			{
				filemanager.set_currentFileNode(temp);    //������ļ����ĵ�ǰ���ֵ
				right = true;    //������ļ�����ǰ��
				updateArrowState();
			});
			currentShowpage->addChild(file_type);
			file_type->setPosition(90,_size.height- _size.height/maxNum*(i+1));     //����
			_file_type->setScale(0.04);
			auto name_inf = CCLabelTTF::create(temp->fname, "UWJACK8", 20);      //����
			char num[5];
			auto size_inf = CCLabelTTF::create(itoa(temp->fcurrentlen, num, 10), "UWJACK8", 20);
			currentShowpage->addChild(name_inf);
			currentShowpage->addChild(size_inf);
			name_inf->setPosition(200, _size.height - _size.height / maxNum*(i + 1));    //����
			size_inf->setPosition(300, _size.height - _size.height / maxNum*(i + 1));     //����
			name_inf->setColor(ccc3(0, 0, 0));
			size_inf->setColor(ccc3(0, 0, 0));
			auto addr_inf = CCLabelTTF::create(temp->fadress, "UWJACK8", 20);
			currentShowpage->addChild(addr_inf);
			addr_inf->setPosition(450, _size.height - _size.height / maxNum*(i + 1));
			addr_inf->setColor(ccc3(0, 0, 0));
			//MessageBox("Not NULL!", "");
		}
	}
}

void Scene_2::_open(FCB* openNode)       //���ļ���ť���ܺ�nextPageShow����һ��
{
	if (right==false) { MessageBox("Please select a file to open!",""); return; }
	
	////////////////�ɹ����޸�rightֵ��is_search_page��ֵ
	//if(openNode->ftype=="package")                //����һ���ļ����Ժ󣬵�ַ�Զ���Ϊ��������ַ
	right = false;
	updateArrowState();
		if (openNode->ftype == "package")       ////��"package"����
		{
			is_search_page =false;
			reshow_thispackage(openNode);
			this->removeChild(currentadress);
			string newAddr = openNode->fadress + ">" + openNode->fname;
			currentadress = CCLabelTTF::create(newAddr.c_str(), "UWJACK8", 25);
			this->addChild(currentadress);
			currentadress->setColor(ccc3(33, 33, 222));
			currentadress->setAnchorPoint(Vec2(0, 0));
			currentadress->setPosition(180, size.height - 40);
			filemanager.set_currentParent(openNode);
			updateArrowState();
			return;
		}
		else              //��"doc"���ԣ���������Ĺ���
		{
			//////չʾ�ĵ�����
			doc_show = Sprite::create("doc_content.png");          //��СΪ960*640
			this->addChild(doc_show,31);
			doc_show->setPosition(size.width / 2, size.height / 2);
			doc_content = CCLabelTTF::create(openNode->fcontent.c_str(), "UWJACK8", 30);
			doc_show->addChild(doc_content);
			doc_content->setPosition(size.width / 2, size.height - 100);
			doc_content->setColor(ccc3(0, 0, 0));
			///////�ر��ĵ���ť
			_close_doc = MenuItemImage::create("close_doc_1.png", "close_doc_2.png");
			close_doc = Menu::create(_close_doc, NULL);
			doc_show->addChild(close_doc);
			close_doc->setPosition(900, 600);        //����
			_close_doc->setCallback([=](Ref*obj)
			{
				this->removeChild(doc_show);
				reshow_thispackage(openNode->fparent);
				//right = false;
			});
			////���빦�ܣ���д�Ĺ���
			auto _writeBox = Sprite::create("writeBox.png");
			_writeBox->setPosition(120, size.height - 120);    //����
			doc_show->addChild(_writeBox);
			auto writeBox = EditBox::create(Size(_writeBox->getContentSize()), Scale9Sprite::create("writeBox.png"));
			writeBox->setPosition(_writeBox->getPosition());
			writeBox->setMaxLength(1000);
			writeBox->setPlaceHolder("Please input the text:");
			writeBox->setText(openNode->fcontent.c_str());
			writeBox->setFontColor(Color3B(0,0,0));
			writeBox->setFont("UWJACK8", 20);
			doc_show->addChild(writeBox);
			auto _ensure_genggai = MenuItemImage::create("genggai_1.png", "genggai_2.png");
			//_ensure_genggai->setPosition(size.width / 2 + 50,size.height-10);       //����
			string new_content;
			_ensure_genggai->setCallback([=](Ref*obk)
			{
				char *_new_content =(char*) writeBox->getText();
				string new_content = Value(_new_content).asString();
				if (!filemanager.is_will_full(openNode->fcontent, new_content))       //���Ӳ�̿ռ��Ƿ�����
				{////////Ӳ�̿ռ�δ��
					//bool is_can_write=true;
					filemanager.reset_content(new_content);
					/////����չʾӲ�����ڿ��ÿռ�
					this->removeChild(Csize, true);
					char clen[10];
					Csize = CCLabelTTF::create(itoa(filemanager.getcurrentlen(), clen, 10), "UWJACK8", 10);
					this->addChild(Csize);
					Csize->setPosition(70, 185);
					Csize->setColor(ccc3(236, 25, 25));

					/////����չʾ�ĵ���������
					doc_show->removeChild(doc_content, true);
					doc_content = CCLabelTTF::create(openNode->fcontent.c_str(), "UWJACK8", 30);
					doc_show->addChild(doc_content);
					doc_content->setPosition(size.width / 2, size.height - 100);
					doc_content->setColor(ccc3(0, 0, 0));
					//writeBox->setText("");
				}
				else
				{
					//is_can_write = false;           //����д�룬�ĵ����ݱ��ֲ���
					MessageBox("Sorry!The content you changed will make the space overrupted!\nSo,the content will return to the original condition!", "");
					writeBox->setText(openNode->fcontent.c_str());
				}
			});
			auto ensure_genggai = Menu::create(_ensure_genggai, NULL);
			ensure_genggai->setPosition(120, size.height-180);      //����
			doc_show->addChild(ensure_genggai);
		}
}

void Scene_2::_delete(Ref * p)
{
	if (right == false)
	{
		MessageBox("Please select the file you want to delete!", "");
		return;
	}
	right = false;
	updateArrowState();
	filemanager.delete_curnode(filemanager.get_currentNode());
	//////////������ʾ��ǰ������Ϣ��
	reshow_thispackage(filemanager.get_currentParent());
	/////����չʾӲ�����ڿ��ÿռ�
	this->removeChild(Csize, true);
	char clen[10];
	Csize = CCLabelTTF::create(itoa(filemanager.getcurrentlen(), clen, 10), "UWJACK8", 10);
	this->addChild(Csize);
	Csize->setPosition(70, 185);
	Csize->setColor(ccc3(236, 25, 25));
}

void Scene_2::_show_attribute(Ref * p)
{
	if (right == false)
	{
		MessageBox("Please select a file!", "");
		return;
	}
	//if (filemanager.get_currentNode() == NULL)return;
	right = false;
	updateArrowState();    //////���¼�ͷ״̬
	attr = Sprite::create("fileattr.png");
	this->addChild(attr,100);
	attr->setPosition(size.width / 2, size.height / 2);
	Sprite* tubiao;
	if (filemanager.get_currentNode()->ftype == "doc")tubiao = Sprite::create("doc.png");   //�ļ���ͼ��
	else tubiao = Sprite::create("package.png");
	attr->addChild(tubiao);
	tubiao->setScale(0.05);
	tubiao->setPosition(size.width/2, 600);         //����
	attribute temp = filemanager.get_attribute();
	auto other = CCLabelTTF::create("File name:\n\nFile type:\n\nFile state:\n\nCurrent size:\n\nAdress:\n\n", "UWJACK8", 30);
	attr->addChild(other);
	other->setPosition(300, size.height / 2-25);
	other->setColor(ccc3(100, 100, 100));
	Value attr0 = Value( temp.name ); 
	Value attr1 = Value("\n\n" + temp.type);
	Value attr2 = Value("\n\n" + temp.state+"\n\n");
	char num[10];
	Value attr3=Value(itoa(temp.currentlen,num,10)) ;
	Value attr4 = Value("\n\n" + temp.adress);
	string _attr = attr0.asString() + attr1.asString() + attr2.asString() + attr3.asString() + attr4.asString();
	auto attr_content = CCLabelTTF::create(_attr, "UWJACK8", 30);
	attr->addChild(attr_content);
	attr_content->setColor(ccc3(0, 0, 0));
	attr_content->setPosition(size.width/2, size.height/2);       //����
	_close_attr = MenuItemImage::create("close_attr_1.png", "close_attr_2.png");
	_close_attr->setCallback([=](Ref*obj) 
	{
		this->removeChild(attr,true);
	});
	close_attr = Menu::create(_close_attr, NULL);
	attr->addChild(close_attr);
	close_attr->setPosition(800, 600);        //����

}

void Scene_2::_rename(Ref * p)
{
	if (is_valid == false)
	{
		MessageBox("Please finish your other operations first!", "");
		return;
	}
	is_valid = false;
	//if (filemanager.get_currentNode() == NULL)return;
	if (right == false)
	{
		MessageBox("Please select a file to rename!", "");
		is_valid = true;
		return;
	}
	right = false;
	FCB* temp = filemanager.get_currentNode();
	updateArrowState();

	//�������
	auto nameBox = Sprite::create("namebox1.png");
	this->addChild(nameBox);
	nameBox->setScaleX(3);
	nameBox->setPosition(size.width / 2, size.height / 2);
	auto setnameBox = EditBox::create(Size(nameBox->getContentSize().width*3, nameBox->getContentSize().height), Scale9Sprite::create("namebox1.png"));
	//setnameBox->setScale(0.15);
	setnameBox->setPosition(nameBox->getPosition());
	setnameBox->setMaxLength(20);
	setnameBox->setText("Please input the new name:");
	setnameBox->setFontColor(Color3B(100,100,100));
	setnameBox->setFontSize(20);
	this->addChild(setnameBox);

	string oldname = temp->fname;
	auto nameokButt = MenuItemImage::create("nameok_1.png", "nameok_2.png");       //ͼƬ����
	nameokButt->setCallback([=](Ref*obj) {
		char *_newname = (char*)setnameBox->getText();
		string newname = Value(_newname).asString();
		bool is_name_repeated= filemanager.is_name_repeated(newname, temp->ftype);
		if (is_name_repeated)
		{
			show_repeatemessage();
			this->removeChild(nameBox, true);
			this->removeChild(setnameBox, true);
			//updateArrowState();
			is_valid = true;
			return;
		}
		else
		{
			//////�������ɹ�,������ʾ��ҳ����
			temp->fname = newname;
			this->removeChild(nameBox, true);
			this->removeChild(setnameBox, true);
			reshow_thispackage(filemanager.get_currentParent());
			//updateArrowState();
			is_valid = true;
		}
	});
	//nameokButt->setScale(0.07);
	auto okMenu = Menu::create(nameokButt, NULL);
	okMenu->setPosition(300,18);
	nameokButt->setScale(0.7);
	setnameBox->addChild(okMenu);
}

void Scene_2::lastPageShow(FCB* pa_node)        //����ΪҪչʾ����һҳ�Ľ��
{
	if (is_search_page == false)    //������չʾҳ��ǰһҳ
	{
		///////////������
		filemanager.set_currentParent(pa_node->fparent);
		right == false;
		if (pa_node == filemanager.get_direc_head())left = false;
		else left = true;
		////////////��ͷ����
		updateArrowState();
		///////////��ַ����
		this->removeChild(currentadress);
		string newAddr = pa_node->fadress;
		currentadress = CCLabelTTF::create(newAddr.c_str(), "UWJACK8", 30);
		this->addChild(currentadress);
		currentadress->setPosition(180, size.height - 30);
		currentadress->setColor(ccc3(33, 33, 222));
		///////////չʾ���ݸ���
		reshow_thispackage(pa_node->fparent);
	}
	else     //����չʾҳ��ǰһҳ
	{
		is_search_page = false;
		right = false;
		updateArrowState();    //���¼�ͷ״̬
		///////////����չʾ�ϴ�ҳ������
		reshow_thispackage(pa_node);
		///////////��ַ����
		this->removeChild(currentadress);
		string newAddr;
		if (pa_node == filemanager.get_direc_head())newAddr = "C";
		else
		{
			newAddr = pa_node->fadress + ">" + pa_node->fname;
		}
		currentadress = CCLabelTTF::create(newAddr.c_str(), "UWJACK8", 30);
		this->addChild(currentadress);
		currentadress->setPosition(180, size.height - 30);
		currentadress->setColor(ccc3(33, 33, 222));
	}
}

void Scene_2::updateArrowState()
{
	this->removeChild(arrowMenu);
	FCB* _cur_node = filemanager.get_currentNode();
	FCB* _cur_pa = filemanager.get_currentParent();
	FCB* _head = filemanager.get_direc_head();
	if (_cur_pa == _head&&is_search_page==false)left = false;     //��ǰ�����Ϊͷ����Ҳ���չʾҳ�����ͷʧЧ
	else left = true;
	if (left==true&&right==true)
	{
		leftarrow1 = MenuItemImage::create("backButt.png", "backButt_down.png");
		leftarrow1->setCallback([=](Ref*obj) 
		{
			lastPageShow(_cur_pa);
		});
		rightarrow1 = MenuItemImage::create("nextButt.png", "nextButt_down.png");
		rightarrow1->setCallback([=](Ref*obj) {_open(_cur_node); });
		arrowMenu = Menu::create(leftarrow1, rightarrow1, NULL);
		this->addChild(arrowMenu);
		leftarrow1->setScale(0.13);
		rightarrow1->setScale(0.13);
		arrowMenu->alignItemsHorizontallyWithPadding(5);
		arrowMenu->setPosition(50, size.height - 30);
		return;
	}
	if (left==false&&right==true)
	{
		leftarrow0 = MenuItemImage::create("_backButt.png", "_backButt.png");
		leftarrow0->setCallback([=](Ref*obj) {MessageBox("This is the fist page!", ""); });
		rightarrow1 = MenuItemImage::create("nextButt.png", "nextButt_down.png");
		rightarrow1->setCallback([=](Ref*obj) {_open(_cur_node); });
		arrowMenu = Menu::create(leftarrow0, rightarrow1, NULL);
		this->addChild(arrowMenu);
		leftarrow0->setScale(0.13);
		rightarrow1->setScale(0.13);
		arrowMenu->alignItemsHorizontallyWithPadding(5);
		arrowMenu->setPosition(50, size.height - 30);
		return;
	}
	if (left==true&&right==false)
	{
		rightarrow0 = MenuItemImage::create("_nextButt.png", "_nextButt.png");
		rightarrow0->setCallback([=](Ref*obj) {MessageBox("Please select a file to open!",""); });
		leftarrow1 = MenuItemImage::create("backButt.png", "backButt_down.png");
		leftarrow1->setCallback([=](Ref*obj)
		{
			lastPageShow(_cur_pa);
		});
		arrowMenu = Menu::create(leftarrow1, rightarrow0, NULL);
		this->addChild(arrowMenu);
		leftarrow1->setScale(0.13);
		rightarrow0->setScale(0.13);
		arrowMenu->alignItemsHorizontallyWithPadding(5);
		arrowMenu->setPosition(50, size.height - 30);
		return;
	}
	if (left==false&&right==false)
	{
		leftarrow0 = MenuItemImage::create("_backButt.png", "_backButt.png");
		leftarrow0->setCallback([=](Ref*obj) {MessageBox("This is the fist page!", ""); });
		rightarrow0 = MenuItemImage::create("_nextButt.png", "_nextButt.png");
		rightarrow0->setCallback([=](Ref*obj) {MessageBox("Please select a file to open!", ""); });
		arrowMenu = Menu::create(leftarrow0, rightarrow0, NULL);
		this->addChild(arrowMenu);
		leftarrow0->setScale(0.13);
		rightarrow0->setScale(0.13);
		arrowMenu->alignItemsHorizontallyWithPadding(5);
		arrowMenu->setPosition(50, size.height - 30);
		return;
	}
}




