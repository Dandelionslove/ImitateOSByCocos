#pragma once
#ifndef _QUEUE_H_
#define _QUEUE_H_

#include<iostream>
#include<stdlib.h>

using namespace std;

class Queue
{
public:
	Queue();
	~Queue() { makeEmpty(); }
	void makeEmpty();
	bool DeQueue();      //rear����
	bool EnQueue(int adress);  //����head
	bool IsEmpty() { return length == 0; }
	bool IsFull() { return length == 4; }
	int getSize() { return length; }
	bool IsSearch(int _page_num);
	void getArray(int a[4])
	{
		for (int i = 0; i < 4; i++)
		{
			a[i] = Q[i];
		}
	}
private:
	int length;  //���г��ȣ��ɴ����ڴ���ҳ������
	int Q[4];
};



#endif
