#include"BeginningScene.h"
#include<algorithm>


Scene * BeginningScene::createScene()
{
	auto scene = Scene::create();
	auto layer = BeginningScene::create();
	scene->addChild(layer);
	return scene;
}

bool BeginningScene::init()
{
	if (!Layer::init())
	{
		return false;
	}
	size = Director::getInstance()->getVisibleSize();
	//����
	auto background = Sprite::create("background.png");
	this->addChild(background);
	background->setScale((double)960 / (double)1890, (double)640 / (double)1417);
	background->setPosition(size.width / 2, size.height / 2);
	//��ʼ�����ı���
	auto title = Sprite::create("title.png");
	this->addChild(title);
	title->setScale(0.5, 0.5);
	title->setPosition(size.width / 2, size.height/2);
	auto showUp_1 = CCScaleBy::create(1.0f,2);
	auto showUp_2 = CCScaleBy::create(1.0f, 0.75);
	auto actions = CCSpawn::create(showUp_1, showUp_2, NULL);
	title->runAction(actions);
	//��ֵ��ʼ��
	m0 = 0;
	m1 = 0;
	m2 = 0;
	exNum = 0;
	missPage_1 = missPage_2 = 0;
	_l0= _l1= _l2= _l3=_f0=_f1= _f2=_f3=false;
	//ָ����������
	srand((unsigned)time(NULL));
	for (int j = 0; j < 320; )
	{
		m0 = rand() % Ins;
		instruc[j++] = m0;
		if (m0 < 319&&j<320)
		{
			instruc[j++] = m0 + 1;
		}
		if (m0 != 0 && j < 320)
		{
			m1 = rand() % m0;
			instruc[j++] = m1;
			if (m1 < 319 && j < 320)
			{
				instruc[j++] = m1 + 1;
			}
			if (m1 + 1 < 319 && j < 320)
			{
				m2 = m1 + 2 + rand() % (320 - m1 - 2);
				instruc[j++] = m2;
				if (m2 < 319 && j < 320)
				{
					instruc[j++] = m2 + 1;
				}
			}
		}
	}
	//
	auto next_0 = CallbackTimeCounter::create();
	this->addChild(next_0);
	next_0->start(1.5f, [=]
	{
		this->removeChild(title, true);
		begin = MenuItemImage::create("begin.png", "begin.png", CC_CALLBACK_1(BeginningScene::Begin, this));
		close = MenuItemImage::create("close.png", "close.png", CC_CALLBACK_1(BeginningScene::Close, this));
		menu_1 = Menu::create(begin, NULL);
		this->addChild(menu_1,10);
		menu_1->setPosition(size.width / 2, size.height / 2);
		menu_2 = Menu::create(close, NULL);
		this->addChild(menu_2,10);
		menu_2->setPosition(685, 200);
		menu_2->setScale(0.6);
		//Memory����
		Mem = Sprite::create("Mem.png");
		this->addChild(Mem, 1);
		Mem->setPosition(size.width/2,size.height/2);   
		Mem->setScale((double)900 / (double)4000, (double)700 / (double)2000);

		//������ַ��ʾ��ʼ��
		physical_1 = CCLabelTTF::create("NULL", "UWJACK8", 30);
		physical_2 = CCLabelTTF::create("NULL", "UWJACK8", 30);
		this->addChild(physical_1, 5);
		this->addChild(physical_2, 5);
		physical_1->setPosition(295,120);   
		physical_2->setPosition(665, 120);   
		physical_1->setColor(ccc3(200, 90,60));
		physical_2->setColor(ccc3(200, 90, 60));
		//ȱҳ����ʾ���س�ʼ��

		//�Ѿ�ִ��ָ��������ʾ��ʼ��
		ExeInsNum = CCLabelTTF::create("0", "UWJACK8", 50);
		this->addChild(ExeInsNum, 5);
		ExeInsNum->setPosition(size.width / 2, size.height / 2+50);   
		ExeInsNum->setColor(ccc3(100, 190, 60));

		//ȱҳ������ʾ��ʼ��
		miss_1 = CCLabelTTF::create("0", "UWJACK8", 30);
		miss_2 = CCLabelTTF::create("0", "UWJACK8", 30);
		this->addChild(miss_1,5);
		this->addChild(miss_2,5);
		miss_1->setPosition(280, 225);    
		miss_2->setPosition(665, 225);    
		miss_1->setColor(ccc3(200, 90, 160));
		miss_2->setColor(ccc3(200, 90, 160));

	});

	return true;
}

void BeginningScene::Begin(Ref * pSender)
{
	this->removeChild(menu_1, true);
	this->schedule(schedule_selector(BeginningScene::updateDealingIns),0.01f);     //ÿ��һ��ִ��һ��ָ��
}

void BeginningScene::Close(Ref * Sender)
{
	MessageBox("You pressed the close button.The application is over!", "Alert");
	CCDirector::sharedDirector()->end();

	exit(0);
}

void BeginningScene::LRU(int i)
{
	int page_num = i / 10 + 1;
	int offset = i % 10;
	bool is_search = Llist.IsSearch(page_num);
	if (is_search==true)
	{
		//��ʾ��������ַ
		this->removeChild(physical_1, true);
		char _bottle[6] = { '\0' };
		physical_1 = CCLabelTTF::create(itoa((page_num-1) * 10 + offset, _bottle,10), "UWJACK8", 25);
		this->addChild(physical_1, 10);
		physical_1->setPosition(295, 120);     
		physical_1->setColor(ccc3(200, 90, 60));

		this->updateLMem();              //��Ϊ��LRU�в��ҵ���ʱ������޸�˳�򣬹�Ҫ����ҳ����ʾ
		return;
	}
	else
	{
		if (!Llist.IsFull())
		{
			Llist.Insert(page_num);
			this->updateLMem();
		}
		else
		{
			Llist.Delete();
			Llist.Insert(page_num);
			this->updateLMem();
		}
		missPage_1++;
		this->removeChild(miss_1);
		char _bottle[6] = { '\0' };
		miss_1 = CCLabelTTF::create(itoa(missPage_1, _bottle, 10), "UWJACK8", 30);
		this->addChild(miss_1, 5);
		miss_1->setPosition(280, 225);  
		miss_1->setColor(ccc3(200, 90, 160));

		return;
	}
	
}

void BeginningScene::FIFO(int i)
{
	int page_num = i / 10 + 1;
	int offset = i % 10;
	bool is_search = FIFOqu.IsSearch(page_num);
	if (is_search==true)
	{
		//��ʾ��������ַ
		this->removeChild(physical_2,true);
		char _bottle[6] = { '\0' };
		physical_2 = CCLabelTTF::create(itoa((page_num-1)*10+offset, _bottle, 10), "UWJACK8", 25);
		this->addChild(physical_2, 5);
		physical_2->setPosition(700, 120);   
		physical_2->setColor(ccc3(200, 90, 60));

		return;
	}
	else
	{
		if (!FIFOqu.IsFull())
		{
			FIFOqu.EnQueue(page_num);
			this->updateFMem();
		}
		else
		{
			FIFOqu.DeQueue();
			FIFOqu.EnQueue(page_num);
			this->updateFMem();
		}
		missPage_2++;
		this->removeChild(miss_2);
		char _bottle[6] = { '\0' };
		miss_2 = CCLabelTTF::create(itoa(missPage_2, _bottle, 10), "UWJACK8", 30);
		this->addChild(miss_2, 5);
		miss_2->setPosition(665, 225);
		miss_2->setColor(ccc3(200, 90, 160));

		return;
	}
	
}

void BeginningScene::updateInsExeNum()
{
	this->removeChild(ExeInsNum, true);
	char _bottle[6] = { '\0' };
	ExeInsNum = CCLabelTTF::create(itoa(exNum, _bottle, 10), "UWJACK8", 50);
	this->addChild(ExeInsNum, 5);
	ExeInsNum->setPosition(size.width / 2, size.height / 2 + 50);
	ExeInsNum->setColor(ccc3(100, 190, 60));

}

void BeginningScene::showResult()
{
	perc_1 = (double)missPage_1 / (double)exNum;
	perc_2 = (double)missPage_2 / (double)exNum;
	//char _bottle_1[10] = { '\0' };
	result_1 = CCLabelTTF::create(Value(perc_1).asString(), "UWJACK8", 25);
	this->addChild(result_1,6);
	result_1->setPosition(350, 70);      
	result_1->setColor(ccc3(200, 100, 70));
	result_2 = CCLabelTTF::create(Value(perc_2).asString(), "UWJACK8", 25);
	this->addChild(result_2,6);
	result_2->setPosition(720, 70);  
	result_2->setColor(ccc3(200, 100, 70));

}

void BeginningScene::updateLMem()
{
	Llist.getArray(l);
	if (_l0 == true)
	{
		this->removeChild(l0);
	}
	if (l[0] != -1)       //Llist�е�һ������������
	{
		char _bottle[6] = { '\0' };
		l0 = CCLabelTTF::create(itoa(l[0], _bottle, 10), "UWJACK8", 25);
		this->addChild(l0,6);
		l0->setPosition(280, 500);
		l0->setColor(ccc3(100, 30, 150));
		_l0 = true;
	}

	if (_l1 == true)
	{
		this->removeChild(l1);
	}
	if (l[1] != -1)
	{
		char _bottle[6] = { '\0' };
		l1 = CCLabelTTF::create(itoa(l[1], _bottle, 10), "UWJACK8", 25);
		this->addChild(l1,6);
		l1->setPosition(280,430);
		l1->setColor(ccc3(100, 30, 150));
		_l1 = true;
	}
	if (_l2 == true)
	{
		this->removeChild(l2);
	}
	if (l[2] != -1)
	{
		char _bottle[6] = { '\0' };
		l2 = CCLabelTTF::create(itoa(l[2], _bottle, 10), "UWJACK8", 25);
		this->addChild(l2,6);
		l2->setPosition(280,360);
		l2->setColor(ccc3(100, 30, 150));

		_l2 = true;
	}
	if (_l3 == true)
	{
		this->removeChild(l3);
	}
	if (l[3] != -1)
	{
		char _bottle[6] = { '\0' };
		l3 = CCLabelTTF::create(itoa(l[3], _bottle, 10), "UWJACK8", 25);
		this->addChild(l3,6);
		l3->setPosition(280,290);
		l3->setColor(ccc3(100, 30, 150));

		_l3 = true;
	}
	return;
}    

void BeginningScene::updateFMem()
{
	FIFOqu.getArray(f);

	if (_f0 == true)
	{
		this->removeChild(f0);
	}
	if (f[0] != -1)
	{
		char _bottle[6] = { '\0' };
		f0 = CCLabelTTF::create(itoa(f[0], _bottle, 10), "UWJACK8", 25);
		this->addChild(f0,6);
		f0->setPosition(685, 500);
		f0->setColor(ccc3(100, 30, 150));

		_f0 = true;
	}

	if (_f1 == true)
	{
		this->removeChild(f1);
	}
	if (f[1] != -1)
	{
		char _bottle[6] = { '\0' };
		f1 = CCLabelTTF::create(itoa(f[1], _bottle, 10), "UWJACK8", 25);
		this->addChild(f1, 6);
		f1->setPosition(685, 430);
		f1->setColor(ccc3(100, 30, 150));

		_f1 = true;
	}

	if (_f2 == true)
	{
		this->removeChild(f2);
	}
	if (f[2] != -1)
	{
		char _bottle[6] = { '\0' };
		f2 = CCLabelTTF::create(itoa(f[2], _bottle, 10), "UWJACK8", 25);
		this->addChild(f2, 6);
		f2->setPosition(685, 360);
		f2->setColor(ccc3(100, 30, 150));

		_f2 = true;
	}

	if (_f3 == true)
	{
		this->removeChild(f3);
	}
	if (f[3] != -1)
	{
		char _bottle[6] = { '\0' };
		f3 = CCLabelTTF::create(itoa(f[3], _bottle, 10), "UWJACK8", 25);
		this->addChild(f3, 6);
		f3->setPosition(685, 290);
		f3->setColor(ccc3(100, 30, 150));

		_f3 = true;
	}
}

void BeginningScene::updateDealingIns(float df)
{
	LRU(instruc[exNum]);
	FIFO(instruc[exNum]);
	//CCLOG("%d",instruc[exNum]);    //������
	exNum++;
	this->updateInsExeNum();
	if (exNum == 320)
	{
		this->showResult();
		//this->unschedule(schedule_selector(BeginningScene::updateDealingIns));
		this->unscheduleAllSelectors();
	}
}




