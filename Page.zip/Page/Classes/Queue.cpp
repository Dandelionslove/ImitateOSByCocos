#include "Queue.h"

Queue::Queue():length(0)
{
	for (int i = 0; i < 4; i++)
	{
		Q[i] = -1;                //-1��ʾû��ҳ��ֵ
	}
}

void Queue::makeEmpty()
{
	for (int i = 0; i < 4; i++)Q[i] = -1;
	length = 0;
}

bool Queue::DeQueue()
{
	if (IsEmpty())
	{
		return false;
	}
	int i = 0;
	while (Q[i] != -1 && i < 4)i++;
	Q[i-1] = -1;
	length--;
	return true;
}

bool Queue::EnQueue(int adress)
{
	if (IsFull())return false;
	int i = 3;
	for (; i >= 0 &Q[i] == -1; i--) {}
	for (; i >= 0; i--)
	{
		Q[i + 1] = Q[i];
	}
	Q[0] = adress;
	length++;
	return true;
}

bool Queue::IsSearch(int _page_num)
{
	if(IsEmpty())
	return false;
	for (int i = 0; i < 4; i++)
	{
		if (Q[i] == _page_num)return true;
	}
	return false;
}


