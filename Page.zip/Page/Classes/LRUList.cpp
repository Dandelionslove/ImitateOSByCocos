#include "LRUList.h"

List::List():length(0)
{
	for (int i = 0; i < 4; i++)
	{
		Lpage[i] = -1;
	}
}

void List::MakeEmpty()
{
	length = 0;
	for (int i = 0; i < 4; i++)
	{
		Lpage[i] = -1;
	}
}

bool List::Delete()
{
	if(IsEmpty())
	return false;
	int i = 0;
	for (; i < 4&&Lpage[i]!=-1; i++)
	{
	}
	Lpage[i-1] = -1;
	length--;
	return true;
}

bool List::Insert(int _page_num)
{
	if (IsFull())return false;
	int i = 3;
	for (; i >= 0 && Lpage[i] == -1; i--){}
	for (; i >= 0; i--)
	{
		Lpage[i + 1] = Lpage[i];
	}
	Lpage[0] = _page_num;
	length++;

	return true;
}

bool List::IsSearch(int _page_num)
{
	for (int i = 0; i < 4; i++)
	{
		if (Lpage[i] == _page_num)
		{
			int j = i;
			while (j >0)
			{
				Lpage[j] = Lpage[j - 1];
				j--;
			}
			Lpage[0] = _page_num;
			return true;
		}
	}
	return false;
}

void List::getArray(int a[4])
{
	for (int i = 0; i < 4; i++)
	{
		a[i] = Lpage[i];
	}
}

